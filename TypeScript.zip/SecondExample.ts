//Arrays concepts. 
let elements : number[] = [];
elements.push(123);
elements.push(124);
elements.push(125);
elements.push(126);
elements.push(127);

for (const e of elements) {
    console.log(e);
}
//////Generic type of Array in TS//////////////////////////////
let fruits = Array<string>();
fruits = ["Apple", "Mango", "Orange", "PineApple"];
for (const fruit of fruits) {
    console.log(fruit);
}

//TS allows to create Arrays of multiple data types....
let fruitsAndPrices : (string | number )[] =[
    "Apples", 340, "Mangoes", 100, "Banana", 200    
]

for (const e of fruitsAndPrices) {
 console.log(e);   
}

//PS: all the array methods of JS is available in TS also...
//Tuples: Tuples are pairs of data 
const emp : [number, string ] = [1, "Phaniraj"];
const custBill : [string, number] = ["Somnath", 650];
//Tuples store pairs of data. U can even create arrays of Tuples.

//Any is a data type similar to object where it can hold any kind of data. This is required when U  dont know the datatype at compile time.
let obj : any = "Phaniraj"; //late binding data
console.log(typeof(obj));
//U can create User defined data types in the form of classes...







