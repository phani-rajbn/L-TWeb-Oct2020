//Typescript has abstract classes and interfaces. A class with atleast one abstract method, a method with no implementation, is called abstract classes.
abstract class Account{
    accNo : number;
    accHolder : string;
    protected accBalance : number;

    constructor(no: number, name : string, balance : number) {
        this.accNo = no;
        this.accHolder = name 
        this.accBalance = balance
    }

    getBalance() : number {
         return this.accBalance;   
    } 

    credit(amount : number){
        this.accBalance += amount
    }
    
    debit(amount : number){
        if(amount > this.accBalance)
            throw "Insufficient funds";
        this.accBalance -= amount
    }
    abstract calcInterest();//This function does not have a body...
} 
//A Class that is derived from abstract class must implement the abstract methods. Abstract classes are not instantiatable, they are incomplete. 
class SBAccount extends Account{

    calcInterest() { 
        let r : number = 6.5/100;
        let t : number = 1/4;
        let p : number = super.accBalance;
        let interest : number = p * t* r;
        super.credit(interest);
        //super is used to refer the immediate base class, this is used to refer the current object of the class.   
    }

}

let acc : Account = new SBAccount(123, "Phaniraj", 65000);
acc.credit(23400);
acc.calcInterest();
console.log(acc.getBalance());

//Classes in typescript support data modifiers like private(within the clcaass declaration), public(anywhere), protected(within the class and its derivatives). 