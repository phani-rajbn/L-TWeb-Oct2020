
function addNumbers(num1 : number, num2 : number) : number {
       return num1 + num2; 
}

var sum = addNumbers(123, 234);

console.log(sum);
/*Declare variables in TS. TS is type safe, so UR variables are declared with specific data types supported by JS*/
var age : number = 43; //TS is very strict in data types...
var uName : string = "Phaniraj";
var currentStatus : boolean = true;
//var currentStatus : string ="SomeThing";//Not OK in typescript

var data = `The Name is ${uName} aged ${age}`;
console.log(data);
//variables declared once cannot be redeclared in TS..
//U could use const and let in typescript while declaring the variables. 



