interface Customer{
    cstID : number;
    cstAddress : string;
    cstName : string
}
//interfaces could be created for representing JSON data that U fetch from the REST services...
let cst : Customer = {
    cstID : 123,
    cstName : "Phaniraj",
    cstAddress : "Bangalore"
}

console.log(cst.cstName)
//U could use interfaces in Typescript for creating Abstract methods and allow to be implemented by the derived classes. 

//To Explore: What is significance of Modules and Namespaces in Typescript. 
